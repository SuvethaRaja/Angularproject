import { Component, Inject, Injectable, OnInit } from '@angular/core';
import {FormControl, Validators,FormGroup,FormBuilder} from '@angular/forms';
import { SecondService } from 'src/app/services/second.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { VendorComponent } from '../vendor/vendor.component';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  productform!:FormGroup;
  actionBtn:string="Save"

  constructor(private formbuilder:FormBuilder, private second:SecondService,
    @Inject(MAT_DIALOG_DATA) public editData: any,
    private dialogRef:MatDialogRef<VendorComponent>) { }

  ngOnInit(){

    this.productform=this.formbuilder.group ({ 
      email:['',[Validators.required,Validators.email]],
      ShopName:['',Validators.required],
      category:['',Validators.required],
      PhoneNo:['',Validators.required],
      LicenseNo:['',Validators.required],
      Name:['',Validators.required],
      Adress:['',Validators.required],
    });
    if(this.editData)
    {
      this.actionBtn="Update";
      this.productform.controls['ShopName'].setValue(this.editData.ShopName);
      this.productform.controls['Adress'].setValue(this.editData.Adress);
      this.productform.controls['email'].setValue(this.editData.email);
      this.productform.controls['category'].setValue(this.editData.category);
      this.productform.controls['PhoneNo'].setValue(this.editData.PhoneNo);
      this.productform.controls['LicenseNo'].setValue(this.editData.LicenseNo);
      this.productform.controls['Name'].setValue(this.editData.Name);
    }

  }

addproduct()
{

  if(!this.editData) {
    if(this.productform.valid){
      this.second.postProduct(this.productform.value).subscribe({
        next:(res) => {
          alert("product Added Successfully");
          this.productform.reset();
          this.dialogRef.close('Save');
  
        },
        error:() => {
          alert("error While Adding the Product");
        }
      
      })
    }
  } else {
    this.updateProduct()
  }
}
updateProduct()
{
  this.second.putProduct(this.productform.value,this.editData._id)
  .subscribe ({
    next:(res) => {
      alert("product Updated Successfully");
      this.productform.reset();
      this.dialogRef.close('update');
    },
    error:() =>
    {
      alert("Error While Updating the Record");
    }
  })
}
}
