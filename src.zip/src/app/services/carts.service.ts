import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CartsService {

  constructor(private http:HttpClient) { }
  getproducts()
  {
    //return this.http.get<any> ("https://fakestoreapi.com/products/")
    return this.http.get<any> ("http://localhost:3400/api/pro/getpro")
    .pipe(map((res:any)=>{
      return res;

    }))
  }
}
