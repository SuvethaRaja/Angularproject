import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { ProductComponent } from '../component/product/product.component';
import { Data } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class SecondService {

  

  constructor(private http:HttpClient) { }


  postProduct(data:any){
    
    return this.http.post<any>("http://localhost:3400/api/Product/create",data);
  }
  
  getproduct()
  {
    return this.http.get<any>("http://localhost:3400/api/Product/getProduct");
  }

  putProduct(data:any,_id:number)
    {
    debugger;
    const Data : Data= {_id:_id,data:data}
return this.http.put<any>("http://localhost:3400/api/Product/update/"+_id,data);
  }

  deleteProduct(_id:any){
    debugger;
    //const options =  { headers:new HttpHeaders({'Content-Type':'application/json'}),
    
    //body:{_id} };
    debugger;
    alert("Are u sure Want To Delete");
    
    return this.http.delete<any>("http://localhost:3400/api/Product/delete/"+_id);
    //return this.http.delete<any>(this.node+'delete',options);
  }
  getUser()
{
  return this.http.get<any>("http://localhost:3400/api/User/getUser");
}
}
