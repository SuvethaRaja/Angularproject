import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  public signInForm!: FormGroup;
  constructor(private formBuilder:FormBuilder, private http: HttpClient, private router:Router) { }

  ngOnInit(): void {
    this.signInForm = this.formBuilder.group({
      Email:[''],
      Password:['']
      })
  }

  signin(){
    this.http.get<any>("http://localhost:3400/api/User/getUser")
    .subscribe(res=>{
      const user=res.find((a:any) =>{
          return a.Email === this.signInForm.value.Email && a.Password === this.signInForm.value.Password
      });
      if(user) {
        alert("Login Success!!");
        this.signInForm.reset();
        this.router.navigate(['vendor'])
      } else{
        alert (" user not found!!");
      }
      },err => {
        alert("SomeThing Went Wrong!!");
    })
}
}
