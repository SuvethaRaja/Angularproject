import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule} from '@angular/platform-Browser/animations';
import {MatInputModule} from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import {MatDialogModule } from '@angular/material/dialog';
import { LoginComponent } from './login/login.component';


import { SigninComponent } from './signin/signin.component';
import { MainComponent } from './component/main/main.component';


import {MatSelectModule} from '@angular/material/select';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatIconModule} from '@angular/material/icon';
import {MatDividerModule} from '@angular/material/divider';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import { VendorComponent } from './component/vendor/vendor.component';
import { ProductComponent } from './component/product/product.component';
import {MatTableModule} from '@angular/material/table';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatSortModule} from '@angular/material/sort';
import { DashbordComponent } from './component/dashbord/dashbord.component';
import { CartComponent } from './component/cart/cart.component';
import { CartheaderComponent } from './component/cartheader/cartheader.component';
import { CartproductsComponent } from './component/cartproducts/cartproducts.component';
import { FilterPipe } from './shared/filter.pipe';


 
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SigninComponent,
    MainComponent,
    VendorComponent,
    ProductComponent,
    DashbordComponent,
    CartComponent,
    CartheaderComponent,
    CartproductsComponent,

    FilterPipe,
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatInputModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,  
    MatButtonModule, 
    MatCardModule,
  MatToolbarModule,
  MatSidenavModule,
  MatIconModule,
  MatDividerModule,
  MatButtonToggleModule,
  MatSelectModule,
  MatTableModule,
  MatPaginatorModule,
  MatSortModule


  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
