import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Validators,FormControl, FormGroupDirective, NgForm,FormGroup,FormBuilder} from '@angular/forms';
import { SecondService } from '../services/second.service';
import {Router} from '@angular/router';
import {MatFormFieldModule} from '@angular/material/form-field';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public signupForm!:FormGroup;
  dataSaved=false;
message:any;
submitted=false;
data:any
  ngForm!: FormGroup;
  Email:any;
  //public User!:User[];

  constructor(private formBuilder:FormBuilder, private http: HttpClient, private router:Router, private second: SecondService) { }

  ngOnInit() {
    this.signupForm=this.formBuilder.group({
      Email:['',Validators.required],
      Name:['',Validators.required],
      PhoneNo:['',Validators.required],
      Password:['',Validators.required],

  });
 
  //return this.second.getUser().subscribe((signupForm:User[])=> {
    //this.User=signupForm;
  //});
}



signUp() {
  this.http.post<any>("http://localhost:3400/api/User/create",this.signupForm.value)
.subscribe(res=>{
  alert("signup Successfull");
  this.signupForm.reset();
   this.router.navigate(['signin']);
},
err => {
  alert("SomeThing Went Wrong!!");

});
}



}

function existingEmailValidator(userService: any) {
  throw new Error('Function not implemented.');
}

//export class User {
  //Name:string|any;
  //Email:string | any;
  //Password:string | any;
  //PhoneNo:string | any;
//}