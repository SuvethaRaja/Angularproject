import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SigninComponent } from './signin/signin.component';
import { LoginComponent } from './login/login.component';
import { DashbordComponent } from './component/dashbord/dashbord.component';
import { MainComponent } from './component/main/main.component';
import { VendorComponent } from './component/vendor/vendor.component';
import { CartheaderComponent } from './component/cartheader/cartheader.component';
import { CartproductsComponent } from './component/cartproducts/cartproducts.component';
import { CartComponent } from './component/cart/cart.component';

const routes: Routes = [
  {path:'',redirectTo:'cartproducts',pathMatch:'full'},
  {path:'vendor',component:VendorComponent},
  {path :'main',component:MainComponent},
  {path:'login',component:LoginComponent},
  
  {path:'signin',component:SigninComponent},
  {path:'dashbord',component:DashbordComponent},
  {path:'cartheader',component:CartheaderComponent},
  {path:'cartproducts',component:CartproductsComponent},
  {path:'cart',component:CartComponent},



  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
