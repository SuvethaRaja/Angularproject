const express =require('express');
const mongoose =require('mongoose');
const app= express();
mongoose.connect('mongodb://localhost:27017/Images',{useNewUrlParser:true})
.then(()=>{ console.log("Connected to database")})
.catch(err=> console.log(err))
app.use(express.urlencoded({extended:true}))
app.use(express.json())
app.use(function(req,res,next)
{
res.setHeader('Access-Control-Allow-Origin','*');
res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS,PUT,PATCH,DELETE');
res.setHeader('Access-Control-Allow-Headers','X-Requested-With,content-type');
res.setHeader('Access-Control-Allow-Credentials',true);
next();

})
app.listen(3400,()=>
    console.log('sever is running 3400'))

    const UserController = require('./Controller/UserController');

const ProductController = require('./Controller/ProductController');
const proController = require('./Controller/proController');



app.post("/api/Product/create",ProductController.create);
app.put('/api/Product/update/:id',ProductController.update);
app.get("/api/Product/getProduct",ProductController.getProduct);
app.delete('/api/Product/delete/:id',  ProductController.delete);

// User Schema
app.post('/api/User/create',UserController.create);
app.put('/api/User/update',UserController.update);
app.get("/api/User/getUsers",UserController.getUsers);
    
// pro Schema


app.post('/api/pro/create',proController.create);
app.put('/api/pro/update',proController.update);
app.get('/api/pro/getpro',proController.getpro);