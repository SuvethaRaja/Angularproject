var mongoose = require('mongoose');

var UsersSchema=mongoose.Schema({
    Name:String,
    Email:String,
    PhoneNo:String,
    Password:String
});

module.exports = mongoose.model('Users',UsersSchema);