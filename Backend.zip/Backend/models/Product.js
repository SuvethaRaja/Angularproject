const mongoose=require('mongoose');

const ProductSchema=mongoose.Schema({
    ShopName:String,
    Adress:String,
    email:String,
      category:String,
      PhoneNo:Number,
      LicenseNo:Number,
      Name:String,
    
  


});

module.exports = mongoose.model('Product',ProductSchema);