var mongoose = require('mongoose');

var proSchema=mongoose.Schema({
   id:String,
   title:String,
   price:String,
   description:String,
   category:String,
   image:String,
   rating:Object

});

module.exports = mongoose.model('pro',proSchema);