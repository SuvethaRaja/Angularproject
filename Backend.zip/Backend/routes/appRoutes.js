var express = require('express');

var router = express.Router();
var Users = require('../models/UsersSchema');

router.post('/create',(req,res,next)=> {

      let newUsers = new Users({
            Name:req.body.Name,
            Email:req.body.Email,
            PhoneNo:req.body.PhoneNo,
            Password:req.body.Password,
        
        })
        newUsers.save((err,Users) => {
            if(err)
            res.status(500).json({ errmsg :err});
            res.status(200).json({ msg :Users});

        })
        
      });

router.get('/read',(req,res,next)=> {
          Users.find({},(err,Users)=> {
            if(err)
            res.status(500).json({ errmsg :err});
            res.status(200).json({ msg :Users});
          })
          
   });
   router.put('/update',(req,res,next)=> {

      Users.findById(req.body._id,(err,Users) => {
      if(err)
             res.status(500).json({errmsg:err});
             Users.Name=req.body.Name;
             Users.Email=req.body.Email;
             Users.PhoneNo=req.body.PhoneNo;
             Users.Password=req.body.Password;
            Users.save((err,Users)=> {

                  res.status(500).json({ errmsg :err});
            res.status(200).json({ msg :Country});

            })
    
      })
   });

   router.delete('/delete/:id',(req,res,next)=> {

      Users.findOneAndRemove({_id:req.params.id},(err,Users) => {
            if(err)
                  
            res.status(500).json({ errmsg :err});
                  res.status(200).json({ msg :Country});
      
                  })
               
   });

   module.exports=router;