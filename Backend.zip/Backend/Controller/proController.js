const  proModel= require('../models/pro');

module.exports = {
create:(req,res)=> {
    let pro = new proModel({
        
        id:req.body.id,
   title:req.body.title,
   price:req.body.price,
   description:req.body.description,
   category:req.body.category,
   image:req.body.image,
   rating:req.body.rating
    
    
    })
    pro.save()
    .then(result=> {
        res.json({success:true,result:result})
    })
    .catch(err=> {
        res.json({sucess:false,result:err})
    })
},

update:(req,res)=> {
    proModel.findByIdAndUpdate({_id:req.body._id},req.body)
    .then(pro=>{ 
        res.send(Users)
    })
    .catch(err=> {
        res.json({success:false,result:err})
    })
},
 
getpro: (req,res) => {
 proModel.find()
 .then(pro=> {
    res.send(pro);
 })
 .catch(err=> {
  res.json({success:false,result:"No Students Found"})
 })
 }
}
