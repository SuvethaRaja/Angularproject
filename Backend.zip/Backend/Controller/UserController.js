const UserModel= require('../models/UsersSchema');

module.exports = {
create:(req,res)=> {
    let Users = new UserModel({
        Name:req.body.Name,
        Email:req.body.Email,
        PhoneNo:req.body.PhoneNo,
        Password:req.body.Password
    
    
    })
    Users.save()
    .then(result=> {
        res.json({success:true,result:result})
    })
    .catch(err=> {
        res.json({sucess:false,result:err})
    })
},

update:(req,res)=> {
    UserModel.findByIdAndUpdate({_id:req.body._id},req.body)
    .then(Users=>{ 
        res.send(Users)
    })
    .catch(err=> {
        res.json({success:false,result:err})
    })
},
 
getUsers: (req,res) => {
 UserModel.find()
 .then(Users=> {
    res.send(Users);
 })
 .catch(err=> {
  res.json({success:false,result:"No Students Found"})
 })
 }
}
