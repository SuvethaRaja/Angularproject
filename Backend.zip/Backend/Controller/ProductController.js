//const Product = require('../models/Product');
const proModel= require('../models/Product');

module.exports = {
create:(req,res)=> {
    let Product = new proModel({
       
    ShopName:req.body.ShopName,
    Adress: req.body.Adress,
    email:req.body.email,
      category:req.body.category,
      PhoneNo:req.body.PhoneNo,
      LicenseNo:req.body.LicenseNo,
      Name:req.body.Name,
    
    })
    Product.save()
    .then(result=> {
        res.json({success:true,result:result})
    })
    .catch(err=> {
        res.json({sucess:false,result:err})
    })
},

update:(req,res)=> { 
    /*const Data= new Data({  
        _id: req.body.id,  
        
        ShopName:req.body.ShopName,
        Adress: req.body.Adress,
        email:req.body.email,
          category:req.body.category,
          PhoneNo:req.body.PhoneNo,
          LicenseNo:req.body.LicenseNo,
          Name:req.body.Name,  
          
      });  
    
        proModel.updateOne({_id:req.params.id}, Product).then(result =>{  
            console.log(result);  
            res.status(200).json({message: "Update Successful!"})  
          });  */


    /*proModel.findByIdAndUpdate({_id:req.body._id},req.body)
    .then(Product=>{ 
        res.send(Product)
    })
    .catch(err=> {
        res.json({success:false,result:err})
    })*/



    proModel.findById(req.params.id, function (err, Product) {
        if (!Product)
        return next(new Error('Unable To Find Employee With This Id'));
        else {
        
        
    Product.ShopName=req.body.ShopName,
    Product.Adress= req.body.Adress,
    Product.email=req.body.email,
    Product.category=req.body.category,
    Product.PhoneNo=req.body.PhoneNo,
    Product. LicenseNo=req.body.LicenseNo,
    Product. Name=req.body.Name,
       
        Product.save().then(emp => {
        res.json('Employee Updated Successfully');
        })
        .catch(err => {
        res.status(400).send("Unable To Update Employee");
        });
        }
        });

    
},
 
getProduct: (req,res) => {
 proModel.find()
 .then(Product=> {
    res.send(Product);
 })
 .catch(err=> {
  res.json({success:false,result:"No Students Found"})
 })
 },

 delete:(req,res) =>
 {


    proModel.deleteOne({_id:req.params.id}).then(result=>{  
        console.log(result);  
        res.status(200).json({  
          message:"Product deleted!"  
        });  
    });
    
    /* proModel.findByIdAndRemove( {_id:req.body._id})
    .then(Product=> {
       if(!Product) {
        return res.status(404).send({
        Message:"not Found"
        });    
    }
    res.send({Message:"deleted Successfully"});
    })
    .catch(err=> {
     res.json({success:false,result:"No Students Found"})
    })
    } */

   }  
}
